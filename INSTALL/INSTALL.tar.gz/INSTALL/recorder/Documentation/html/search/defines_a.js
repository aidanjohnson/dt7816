var searchData=
[
  ['night_5fcycle',['NIGHT_CYCLE',['../recorder__helpers_8h.html#ab643aadfd2020832e9f0c13fca31547f',1,'recorder_helpers.h']]],
  ['num_5fbuffs',['NUM_BUFFS',['../recorder__helpers_8h.html#adc512d9640315d0a0d14ead555ea430d',1,'recorder_helpers.h']]],
  ['num_5fchannels',['NUM_CHANNELS',['../recorder__helpers_8h.html#ae5597ce31d23d11493e6e674fe257d73',1,'recorder_helpers.h']]]
];
