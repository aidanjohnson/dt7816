var searchData=
[
  ['comments',['comments',['../structs___a_i_f_f_comment.html#a9efe78edbec4caea12b9ea0d16eaa4c8',1,'s_AIFFComment']]],
  ['commonoffset',['commonOffSet',['../structs___a_i_f_f___ref.html#a820d59d686f3f6fa246654f2cc3194ce',1,'s_AIFF_Ref']]],
  ['construct',['construct',['../structdecoder.html#ace61884a87f9e0a083900a8fa510cefb',1,'decoder']]],
  ['count',['count',['../structs___comment.html#af6a39bfc7e1dc3b6f9c997c1c43fa996',1,'s_Comment']]]
];
