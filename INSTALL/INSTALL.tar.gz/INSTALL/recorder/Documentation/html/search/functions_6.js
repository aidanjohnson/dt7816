var searchData=
[
  ['ieee754_5fread_5fextended',['ieee754_read_extended',['../extended_8c.html#a10922ee943f62ff47e06169134d37410',1,'ieee754_read_extended(uint8_t *in):&#160;extended.c'],['../private_8h.html#ab98ac128e04cd5bbe764acf9d81d4109',1,'ieee754_read_extended(uint8_t *):&#160;extended.c']]],
  ['ieee754_5fwrite_5fextended',['ieee754_write_extended',['../extended_8c.html#a159fa883da17ed0c5b6787d31b50dbce',1,'ieee754_write_extended(double in, uint8_t *out):&#160;extended.c'],['../private_8h.html#a8fc150528572bb7706d3c2fca5d87541',1,'ieee754_write_extended(double, uint8_t *):&#160;extended.c']]],
  ['init_5faifx',['init_aifx',['../aifx_8c.html#aebeeffa2fa0763e5fa9320883ecc043d',1,'init_aifx(AIFF_Ref r):&#160;aifx.c'],['../private_8h.html#a37bb6b38f19556dbd449067843cfcbad',1,'init_aifx(AIFF_Ref):&#160;aifx.c']]],
  ['init_5fsuite',['init_suite',['../newcunittest_8c.html#a11244ab0910e8dbcdf132f10630dea91',1,'newcunittest.c']]],
  ['inittrig',['initTrig',['../recorder__helpers_8c.html#a0eb72d0b41c6a89a239c4798437326b3',1,'initTrig(dt78xx_trig_config_t trig_cfg_ai[]):&#160;recorder_helpers.c'],['../recorder__helpers_8h.html#a0eb72d0b41c6a89a239c4798437326b3',1,'initTrig(dt78xx_trig_config_t trig_cfg_ai[]):&#160;recorder_helpers.c']]]
];
