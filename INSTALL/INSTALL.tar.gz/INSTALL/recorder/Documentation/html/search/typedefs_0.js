var searchData=
[
  ['aiff_5fref',['AIFF_Ref',['../libaiff_8h.html#a01824793153274052db92478790a1550',1,'libaiff.h']]],
  ['aiffloop',['AIFFLoop',['../private_8h.html#a4579cfe26de4e80ead4a5f15563f8409',1,'private.h']]]
];
