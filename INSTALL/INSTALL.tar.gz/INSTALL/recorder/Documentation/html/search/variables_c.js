var searchData=
[
  ['offset',['offset',['../structs___a_i_f_f_sound.html#a894bdfa2d603d8343f8ef01dda6fcd23',1,'s_AIFFSound']]]
];
