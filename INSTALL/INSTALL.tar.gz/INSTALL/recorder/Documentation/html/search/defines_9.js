var searchData=
[
  ['min',['MIN',['../private_8h.html#a74e75242132eaabbc1c512488a135926',1,'private.h']]]
];
