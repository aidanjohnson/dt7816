var searchData=
[
  ['name',['name',['../structs__enc_name.html#a8f8f80d37794cde9472343e4487ba3eb',1,'s_encName']]],
  ['nautical_5ftwilight',['nautical_twilight',['../sunriset_8c.html#ac340adddb16afa0bcfdebb0ff6595823',1,'nautical_twilight(int year, int month, int day, double lon, double lat, double *start, double *end):&#160;sunriset.c'],['../sunriset_8h.html#ac340adddb16afa0bcfdebb0ff6595823',1,'nautical_twilight(int year, int month, int day, double lon, double lat, double *start, double *end):&#160;sunriset.c']]],
  ['nchannels',['nChannels',['../structs___a_i_f_f___ref.html#a8726d5725412b7e1b16285b9f4037938',1,'s_AIFF_Ref']]],
  ['newcunittest_2ec',['newcunittest.c',['../newcunittest_8c.html',1,'']]],
  ['next_5fend_5findex',['next_end_index',['../struct_ring_buf.html#a55a4606155f26c78532e17592cebea5b',1,'RingBuf']]],
  ['night_5fcycle',['NIGHT_CYCLE',['../recorder__helpers_8h.html#ab643aadfd2020832e9f0c13fca31547f',1,'recorder_helpers.h']]],
  ['nmarkers',['nMarkers',['../structs___a_i_f_f___ref.html#a8e768b61f5db750c3e7d7d89fa98be52',1,'s_AIFF_Ref']]],
  ['nsamples',['nSamples',['../structs___a_i_f_f___ref.html#a6155e523a5ff91998afc923213ce2dca',1,'s_AIFF_Ref']]],
  ['num_5fbuffs',['NUM_BUFFS',['../recorder__helpers_8h.html#adc512d9640315d0a0d14ead555ea430d',1,'recorder_helpers.h']]],
  ['num_5fchannels',['NUM_CHANNELS',['../recorder__helpers_8h.html#ae5597ce31d23d11493e6e674fe257d73',1,'recorder_helpers.h']]],
  ['num_5fsamples',['num_samples',['../structcirc__buffer.html#ad3881343367f3f7ea0b279abf2b4e801',1,'circ_buffer']]],
  ['numchannels',['numChannels',['../structs___a_i_f_f_common.html#acc45742113101a540115abfd7b48396a',1,'s_AIFFCommon']]],
  ['numcomments',['numComments',['../structs___a_i_f_f_comment.html#a3e97ef6bc4286c9e9a1ce7c0a3bc95d1',1,'s_AIFFComment']]],
  ['numelements',['numElements',['../struct_ring_buf.html#aaf4c0da3881cc06a72bc84b747c2a350',1,'RingBuf']]],
  ['nummarkers',['numMarkers',['../structs___a_i_f_f_marker.html#ac4e43e016078b2e79163ced3e803d4dd',1,'s_AIFFMarker']]],
  ['numsampleframes',['numSampleFrames',['../structs___a_i_f_f_common.html#ac02ed2f034593d2bff1c48cf6e31bf5c',1,'s_AIFFCommon']]]
];
