var searchData=
[
  ['bool',['bool',['../_ring_buf_8h.html#abb452686968e48b67397da5f97445f5b',1,'RingBuf.h']]]
];
