var searchData=
[
  ['len',['LEN',['../recorder__helpers_8h.html#a05b49c662c073f89e86804f7856622a0',1,'recorder_helpers.h']]],
  ['libaiff',['LIBAIFF',['../aifx_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;aifx.c'],['../extended_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;extended.c'],['../float32_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;float32.c'],['../g711_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;g711.c'],['../iff_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;iff.c'],['../libaiff_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;libaiff.c'],['../lpcm_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;lpcm.c'],['../pascal_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;pascal.c']]],
  ['libaiff_5fapi_5fversion',['LIBAIFF_API_VERSION',['../libaiff_8h.html#a5ce7ce36a74f26eaf54408dd6830f59c',1,'libaiff.h']]],
  ['libaiff_5fnocompat',['LIBAIFF_NOCOMPAT',['../recorder__helpers_8h.html#a7bef5fa8043313f49da3e8006e719105',1,'LIBAIFF_NOCOMPAT():&#160;recorder_helpers.h'],['../recorder__helpers_8h.html#a7bef5fa8043313f49da3e8006e719105',1,'LIBAIFF_NOCOMPAT():&#160;recorder_helpers.h']]],
  ['lpcm_5fbig_5fendian',['LPCM_BIG_ENDIAN',['../libaiff_8h.html#aef62750bc697c5b89a0b5b10cef767e9',1,'libaiff.h']]],
  ['lpcm_5flte_5fendian',['LPCM_LTE_ENDIAN',['../libaiff_8h.html#a87cf5f7f05364597d261008938ebf0f7',1,'libaiff.h']]],
  ['lpcm_5fneed_5fswap',['LPCM_NEED_SWAP',['../libaiff_8h.html#a28ad5cebd7d0d52c358f6bd0f3e9ad81',1,'libaiff.h']]],
  ['lpcm_5fsys_5fendian',['LPCM_SYS_ENDIAN',['../libaiff_8h.html#a756b9e6626fa195629ceb20fbba72cb3',1,'libaiff.h']]]
];
