var searchData=
[
  ['hid',['hid',['../structs___i_f_f_header.html#ab47de47c67893f860865584e1c1aea94',1,'s_IFFHeader']]],
  ['highnote',['highNote',['../structs___instrument.html#a0824fa1116eefddbb8bb69c9629efd5d',1,'s_Instrument']]],
  ['highvelocity',['highVelocity',['../structs___instrument.html#a640d6db5ab252c36bf951f64fbb28a90',1,'s_Instrument']]]
];
