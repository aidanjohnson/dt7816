var searchData=
[
  ['iext',['iext',['../libaiff_8h.html#a9e6fda959bf3d1d88c206ed182907777',1,'libaiff.h']]],
  ['iffchunk',['IFFChunk',['../private_8h.html#a3dc9b3bb95f81b872ee6ee9d55e93e47',1,'private.h']]],
  ['iffheader',['IFFHeader',['../private_8h.html#aa578da3c68c43328d7337ad9d7436ebc',1,'private.h']]],
  ['ifftype',['IFFType',['../libaiff_8h.html#ae86ce006a367c13751887aa11b5c07d4',1,'libaiff.h']]],
  ['instrument',['Instrument',['../libaiff_8h.html#ac16d204e2db70b823d96a1b65d749f3c',1,'libaiff.h']]]
];
