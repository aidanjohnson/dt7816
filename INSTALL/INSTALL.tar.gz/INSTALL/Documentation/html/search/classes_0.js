var searchData=
[
  ['circ_5fbuffer',['circ_buffer',['../structcirc__buffer.html',1,'']]]
];
