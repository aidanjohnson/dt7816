var searchData=
[
  ['set_5fiff_5fattribute',['set_iff_attribute',['../iff_8c.html#ae66853a2c95a8f9df554540193355b2c',1,'set_iff_attribute(AIFF_Ref w, IFFType attrib, char *str):&#160;iff.c'],['../private_8h.html#ae66853a2c95a8f9df554540193355b2c',1,'set_iff_attribute(AIFF_Ref w, IFFType attrib, char *str):&#160;iff.c']]],
  ['sun_5fra_5fdec',['sun_RA_dec',['../sunriset_8c.html#a9910e866c15e5dd400c1856a95d454cc',1,'sunriset.c']]],
  ['sun_5frise_5fset',['sun_rise_set',['../sunriset_8c.html#a671ed9eed37ff33f29bc2f8d05b59ce9',1,'sun_rise_set(int year, int month, int day, double lon, double lat, double *start, double *end):&#160;sunriset.c'],['../sunriset_8h.html#a671ed9eed37ff33f29bc2f8d05b59ce9',1,'sun_rise_set(int year, int month, int day, double lon, double lat, double *start, double *end):&#160;sunriset.c']]],
  ['sunpos',['sunpos',['../sunriset_8c.html#a0d26e7e0c51fdb377cad6ac7c2ba68b8',1,'sunriset.c']]]
];
