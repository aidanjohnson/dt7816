var searchData=
[
  ['find_5fiff_5fchunk',['find_iff_chunk',['../iff_8c.html#aef97ce6e7a1233c54255c280a3123a6f',1,'find_iff_chunk(IFFType chunk, AIFF_Ref r, uint32_t *length):&#160;iff.c'],['../private_8h.html#a7f3ef5b05e9250c650e2e451d54a7cc8',1,'find_iff_chunk(IFFType, AIFF_Ref, uint32_t *):&#160;iff.c']]]
];
