var searchData=
[
  ['vbuf',['vbuf',['../structcirc__buffer.html#a825e1c48ec5172d31a6f9b3b00beb98f',1,'circ_buffer']]]
];
