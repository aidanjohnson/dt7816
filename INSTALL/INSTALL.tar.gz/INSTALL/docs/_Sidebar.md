## Instructions

1. [Acknowledgments](https://github.com/aidanjohnson/dt7816/wiki)

2. [Installing](https://github.com/aidanjohnson/dt7816/wiki/Installing)

3. Connecting:

   3.1. [Setup](https://github.com/aidanjohnson/dt7816/wiki/Connecting:-Setup)

   3.2. [Operation](https://github.com/aidanjohnson/dt7816/wiki/Connecting:-Operation)

4. [Operating](https://github.com/aidanjohnson/dt7816/wiki/Operating)

5. [Troubleshooting](https://github.com/aidanjohnson/dt7816/wiki/Troubleshooting)

## Miscellanea 

* [Circular Buffer](https://github.com/aidanjohnson/dt7816/wiki/Circular-Buffer)

* [Recording Regime](https://github.com/aidanjohnson/dt7816/wiki/Recording-Regime)