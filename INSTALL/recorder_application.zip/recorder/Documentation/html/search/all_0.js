var searchData=
[
  ['_5f_5fdaylen_5f_5f',['__daylen__',['../sunriset_8c.html#a0cddeee5e46ec5968eebf87fd85f045a',1,'sunriset.c']]],
  ['_5f_5fsunriset_5f_5f',['__sunriset__',['../sunriset_8c.html#a2e4ead36c26419cfd929c335b2c2ac48',1,'sunriset.c']]]
];
