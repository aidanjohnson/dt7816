var searchData=
[
  ['openain',['openAIN',['../recorder__helpers_8c.html#a5b731c527193da27f37970f3148a233b',1,'openAIN(int *fd_stream, int *fd_ain):&#160;recorder_helpers.c'],['../recorder__helpers_8h.html#a5b731c527193da27f37970f3148a233b',1,'openAIN(int *fd_stream, int *fd_ain):&#160;recorder_helpers.c']]],
  ['openstream',['openStream',['../recorder__helpers_8c.html#aad66a511457f1e2a929a06be1361d2bd',1,'openStream(int *fd_stream):&#160;recorder_helpers.c'],['../recorder__helpers_8h.html#aad66a511457f1e2a929a06be1361d2bd',1,'openStream(int *fd_stream):&#160;recorder_helpers.c']]]
];
