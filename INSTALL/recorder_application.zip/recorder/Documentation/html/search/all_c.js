var searchData=
[
  ['main',['main',['../main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;main.c'],['../newcunittest_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;newcunittest.c']]],
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['marker',['marker',['../structs___comment.html#a2e45a3d3aeeee3244a4e9a8a7e787dc8',1,'s_Comment::marker()'],['../private_8h.html#acc59073bec243e126e791b0d0e96b444',1,'Marker():&#160;private.h']]],
  ['markerchunk',['MarkerChunk',['../private_8h.html#ac50082768e98de7223a3982bf31023c6',1,'private.h']]],
  ['markerid',['MarkerId',['../libaiff_8h.html#aa057627f607a93b711995e3c7ab48a75',1,'libaiff.h']]],
  ['markername',['markerName',['../structs___marker.html#a5ca29e349fc0c0498e31fc20d6af6c06',1,'s_Marker']]],
  ['markernamelen',['markerNameLen',['../structs___marker.html#a31e1fcc0f5884faf0778bbb5ae33eeef',1,'s_Marker']]],
  ['markeroffset',['markerOffSet',['../structs___a_i_f_f___ref.html#adedc1715afe85288c1e6e17097474dce',1,'s_AIFF_Ref']]],
  ['markerpos',['markerPos',['../structs___a_i_f_f___ref.html#ad242f86648a6ff219db9d9d18e34b401',1,'s_AIFF_Ref']]],
  ['markers',['markers',['../structs___a_i_f_f_marker.html#a5f68c28830b3b44614d6fdce252199f9',1,'s_AIFFMarker']]],
  ['min',['MIN',['../private_8h.html#a74e75242132eaabbc1c512488a135926',1,'private.h']]]
];
