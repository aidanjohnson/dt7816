var searchData=
[
  ['pascalingetlength',['PASCALInGetLength',['../pascal_8c.html#a43e87141d3a81f527fc9a5acf7bb7fb6',1,'PASCALInGetLength(FILE *fd):&#160;pascal.c'],['../private_8h.html#a25caf56c8a25dc513ec1042318bb57de',1,'PASCALInGetLength(FILE *):&#160;pascal.c']]],
  ['pascalinread',['PASCALInRead',['../pascal_8c.html#a8835d29a827c64c3cf91d60a0a8a9100',1,'PASCALInRead(FILE *fd, int *length):&#160;pascal.c'],['../private_8h.html#af191e6b7d76340148f3a99fe124fa17d',1,'PASCALInRead(FILE *, int *):&#160;pascal.c']]],
  ['pascaloutgetlength',['PASCALOutGetLength',['../pascal_8c.html#aae2244cd46b0de4f5862dce27743dac4',1,'PASCALOutGetLength(char *str):&#160;pascal.c'],['../private_8h.html#a06e0f04da0d2fafefd474d98c9a719cc',1,'PASCALOutGetLength(char *):&#160;pascal.c']]],
  ['pascaloutwrite',['PASCALOutWrite',['../pascal_8c.html#a3d904859d597353f8998103e50ecfd96',1,'PASCALOutWrite(FILE *fd, char *str):&#160;pascal.c'],['../private_8h.html#af435a1c1d52c9ab15dded31f6c588c6e',1,'PASCALOutWrite(FILE *, char *):&#160;pascal.c']]]
];
