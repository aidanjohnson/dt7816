var searchData=
[
  ['radeg',['RADEG',['../sunriset_8c.html#a0e4b7f46121b1e51bb52ac02671598e4',1,'sunriset.c']]],
  ['rb_5fatomic_5fend',['RB_ATOMIC_END',['../_ring_buf_8h.html#a396b246b5aadfc32b98fdcc25788a9c8',1,'RingBuf.h']]],
  ['rb_5fatomic_5fstart',['RB_ATOMIC_START',['../_ring_buf_8h.html#a9282a3fa746424c158f79792fb606af2',1,'RingBuf.h']]]
];
