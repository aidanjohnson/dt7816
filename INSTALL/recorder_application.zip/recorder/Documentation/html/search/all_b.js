var searchData=
[
  ['ledindicators',['ledIndicators',['../recorder__helpers_8c.html#a0581036cc3bd6a69d0ea9eb665500cff',1,'ledIndicators(uint8_t status, int streaming):&#160;recorder_helpers.c'],['../recorder__helpers_8h.html#a0581036cc3bd6a69d0ea9eb665500cff',1,'ledIndicators(uint8_t status, int streaming):&#160;recorder_helpers.c']]],
  ['len',['len',['../structs___a_i_f_f___ref.html#accdb2dff228b7a3ea4c3f61937a82412',1,'s_AIFF_Ref::len()'],['../structs___i_f_f_header.html#a96bbf959016e4411c9e6b9812a8be60a',1,'s_IFFHeader::len()'],['../structs___i_f_f_chunk.html#a96bbf959016e4411c9e6b9812a8be60a',1,'s_IFFChunk::len()'],['../struct_ring_buf.html#a77124bd5f7e31e6fffc19f335da0c23f',1,'RingBuf::len()'],['../recorder__helpers_8h.html#a05b49c662c073f89e86804f7856622a0',1,'LEN():&#160;recorder_helpers.h']]],
  ['libaiff',['LIBAIFF',['../aifx_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;aifx.c'],['../extended_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;extended.c'],['../float32_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;float32.c'],['../g711_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;g711.c'],['../iff_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;iff.c'],['../libaiff_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;libaiff.c'],['../lpcm_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;lpcm.c'],['../pascal_8c.html#a1bcf493ce095456dc32cce382b167f60',1,'LIBAIFF():&#160;pascal.c']]],
  ['libaiff_2ec',['libaiff.c',['../libaiff_8c.html',1,'']]],
  ['libaiff_2eh',['libaiff.h',['../libaiff_8h.html',1,'']]],
  ['libaiff_5fapi_5fversion',['LIBAIFF_API_VERSION',['../libaiff_8h.html#a5ce7ce36a74f26eaf54408dd6830f59c',1,'libaiff.h']]],
  ['libaiff_5fnocompat',['LIBAIFF_NOCOMPAT',['../recorder__helpers_8h.html#a7bef5fa8043313f49da3e8006e719105',1,'LIBAIFF_NOCOMPAT():&#160;recorder_helpers.h'],['../recorder__helpers_8h.html#a7bef5fa8043313f49da3e8006e719105',1,'LIBAIFF_NOCOMPAT():&#160;recorder_helpers.h']]],
  ['lownote',['lowNote',['../structs___instrument.html#a493e011b1226157b87062c8bf3068c73',1,'s_Instrument']]],
  ['lowvelocity',['lowVelocity',['../structs___instrument.html#a7e337448bfbb43c826db24f3bf55fa54',1,'s_Instrument']]],
  ['lpcm',['lpcm',['../lpcm_8c.html#af3521fd39bea5d06b8cc9519e9e25d9c',1,'lpcm():&#160;lpcm.c'],['../private_8h.html#af3521fd39bea5d06b8cc9519e9e25d9c',1,'lpcm():&#160;lpcm.c']]],
  ['lpcm_2ec',['lpcm.c',['../lpcm_8c.html',1,'']]],
  ['lpcm_5fbig_5fendian',['LPCM_BIG_ENDIAN',['../libaiff_8h.html#aef62750bc697c5b89a0b5b10cef767e9',1,'libaiff.h']]],
  ['lpcm_5fdequant',['lpcm_dequant',['../lpcm_8c.html#a19f8123573d1af822d79e0fcfe4f0a9e',1,'lpcm_dequant(int segmentSize, void *buffer, float *outSamples, int nSamples):&#160;lpcm.c'],['../private_8h.html#a12d57b295e8d099c6d555f7e023ddb4a',1,'lpcm_dequant(int segmentSize, void *buffer, float *outFrames, int nFrames):&#160;lpcm.c']]],
  ['lpcm_5flte_5fendian',['LPCM_LTE_ENDIAN',['../libaiff_8h.html#a87cf5f7f05364597d261008938ebf0f7',1,'libaiff.h']]],
  ['lpcm_5fneed_5fswap',['LPCM_NEED_SWAP',['../libaiff_8h.html#a28ad5cebd7d0d52c358f6bd0f3e9ad81',1,'libaiff.h']]],
  ['lpcm_5fswap_5fsamples',['lpcm_swap_samples',['../lpcm_8c.html#a56e92586105a26af6cd6941fd8cba93c',1,'lpcm_swap_samples(int segmentSize, int flags, void *from, void *to, int nsamples):&#160;lpcm.c'],['../private_8h.html#a456b32fd1f028ed23255e93b2f8f8c81',1,'lpcm_swap_samples(int, int, void *, void *, int):&#160;lpcm.c']]],
  ['lpcm_5fsys_5fendian',['LPCM_SYS_ENDIAN',['../libaiff_8h.html#a756b9e6626fa195629ceb20fbba72cb3',1,'libaiff.h']]]
];
