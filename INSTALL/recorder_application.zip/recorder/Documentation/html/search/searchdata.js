var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwx",
  1: "cdrs",
  2: "acefgilmnprs",
  3: "_acdfgilmnoprstw",
  4: "abcdefghilmnoprstuv",
  5: "acimrs",
  6: "abcdfhiklmnprstx",
  7: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

