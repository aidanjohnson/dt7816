var searchData=
[
  ['ledindicators',['ledIndicators',['../recorder__helpers_8c.html#a0581036cc3bd6a69d0ea9eb665500cff',1,'ledIndicators(uint8_t status, int streaming):&#160;recorder_helpers.c'],['../recorder__helpers_8h.html#a0581036cc3bd6a69d0ea9eb665500cff',1,'ledIndicators(uint8_t status, int streaming):&#160;recorder_helpers.c']]],
  ['lpcm_5fdequant',['lpcm_dequant',['../lpcm_8c.html#a19f8123573d1af822d79e0fcfe4f0a9e',1,'lpcm_dequant(int segmentSize, void *buffer, float *outSamples, int nSamples):&#160;lpcm.c'],['../private_8h.html#a12d57b295e8d099c6d555f7e023ddb4a',1,'lpcm_dequant(int segmentSize, void *buffer, float *outFrames, int nFrames):&#160;lpcm.c']]],
  ['lpcm_5fswap_5fsamples',['lpcm_swap_samples',['../lpcm_8c.html#a56e92586105a26af6cd6941fd8cba93c',1,'lpcm_swap_samples(int segmentSize, int flags, void *from, void *to, int nsamples):&#160;lpcm.c'],['../private_8h.html#a456b32fd1f028ed23255e93b2f8f8c81',1,'lpcm_swap_samples(int, int, void *, void *, int):&#160;lpcm.c']]]
];
