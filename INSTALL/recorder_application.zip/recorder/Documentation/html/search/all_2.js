var searchData=
[
  ['basenote',['baseNote',['../structs___instrument.html#a91e712dae3311a301ce4999a30332e0c',1,'s_Instrument']]],
  ['beginloop',['beginLoop',['../structs___loop.html#a2de09d98aab9b147a81a5ab3262d9dbb',1,'s_Loop::beginLoop()'],['../structs___a_i_f_f_loop.html#a18313264ef3375dfc70d1bfab3550ce9',1,'s_AIFFLoop::beginLoop()']]],
  ['bitspersample',['bitsPerSample',['../structs___a_i_f_f___ref.html#adca768535e0047312532696c2da78782',1,'s_AIFF_Ref']]],
  ['blocksize',['blockSize',['../structs___a_i_f_f_sound.html#ab6558f40a619c2502fbc24c880fd4fb0',1,'s_AIFFSound']]],
  ['bool',['bool',['../_ring_buf_8h.html#abb452686968e48b67397da5f97445f5b',1,'RingBuf.h']]],
  ['buf',['buf',['../struct_ring_buf.html#ac8ed9b9edf72a0bbde1ba01f0c67ef73',1,'RingBuf']]],
  ['buffer',['buffer',['../structs___a_i_f_f___ref.html#a368f7094dc38acca20612bbb392552f4',1,'s_AIFF_Ref']]],
  ['buffer2',['buffer2',['../structs___a_i_f_f___ref.html#abc628f528f6345b4bb5e8dd4e07e2c70',1,'s_AIFF_Ref']]],
  ['buflen',['buflen',['../structs___a_i_f_f___ref.html#ad6994903b3c19997ffcfdccb4431d308',1,'s_AIFF_Ref']]],
  ['buflen2',['buflen2',['../structs___a_i_f_f___ref.html#ad2b89751f851f9ab8c5c9fd4956c0c09',1,'s_AIFF_Ref']]]
];
