var searchData=
[
  ['gain',['gain',['../structs___instrument.html#a22adbb7dcb5ff8d384e818df21e03b0c',1,'s_Instrument']]],
  ['garbage',['garbage',['../structs___a_i_f_f_loop.html#a3f63c6a01e13e082be6afad78f5576b9',1,'s_AIFFLoop']]]
];
