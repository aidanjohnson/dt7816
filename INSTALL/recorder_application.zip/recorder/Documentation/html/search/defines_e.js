var searchData=
[
  ['tand',['tand',['../sunriset_8c.html#a01a862be86e92b083de9bff9c0326769',1,'sunriset.c']]],
  ['trig_5flevel_5fv',['TRIG_LEVEL_V',['../recorder__helpers_8h.html#a32e1407a44683d7d34836b55573b0769',1,'recorder_helpers.h']]]
];
