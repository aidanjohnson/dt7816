var searchData=
[
  ['nautical_5ftwilight',['nautical_twilight',['../sunriset_8c.html#ac340adddb16afa0bcfdebb0ff6595823',1,'nautical_twilight(int year, int month, int day, double lon, double lat, double *start, double *end):&#160;sunriset.c'],['../sunriset_8h.html#ac340adddb16afa0bcfdebb0ff6595823',1,'nautical_twilight(int year, int month, int day, double lon, double lat, double *start, double *end):&#160;sunriset.c']]]
];
