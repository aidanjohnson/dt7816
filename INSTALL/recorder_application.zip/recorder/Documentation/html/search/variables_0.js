var searchData=
[
  ['add',['add',['../struct_ring_buf.html#a0bd3bf32005e0195a7cd9c432aa9458c',1,'RingBuf']]],
  ['alaw',['alaw',['../g711_8c.html#a49d9428a0da06296465513113223e909',1,'alaw():&#160;g711.c'],['../private_8h.html#a49d9428a0da06296465513113223e909',1,'alaw():&#160;g711.c']]],
  ['audioformat',['audioFormat',['../structs___a_i_f_f___ref.html#a6aa95b027e131c767fe7bfdc8d540137',1,'s_AIFF_Ref']]]
];
