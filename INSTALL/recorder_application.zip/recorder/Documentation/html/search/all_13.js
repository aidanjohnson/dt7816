var searchData=
[
  ['ulaw',['ulaw',['../g711_8c.html#a90cdf825e4d09a9fc56966d017114c04',1,'ulaw():&#160;g711.c'],['../private_8h.html#a90cdf825e4d09a9fc56966d017114c04',1,'ulaw():&#160;g711.c']]]
];
