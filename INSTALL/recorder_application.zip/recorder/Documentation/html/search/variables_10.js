var searchData=
[
  ['text',['text',['../structs___comment.html#a82712cbd12098a88c7839741735b89c2',1,'s_Comment']]],
  ['tics',['tics',['../structs___a_i_f_f___ref.html#a11d7e23e9690ffaca8a2b9efe9a47833',1,'s_AIFF_Ref']]],
  ['timestamp',['timeStamp',['../structs___comment.html#a14f2f551e17c79e8c284c59873d89cd5',1,'s_Comment']]]
];
