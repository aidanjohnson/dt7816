var searchData=
[
  ['kiffnumattributes',['kIFFNumAttributes',['../iff_8c.html#a2e0bcfe15819b378532fc86f117dff57',1,'iff.c']]],
  ['kmodeforwardbackwardlooping',['kModeForwardBackwardLooping',['../libaiff_8h.html#a00b0f33cc79939f8d2b0bbfdeb01ae66',1,'libaiff.h']]],
  ['kmodeforwardlooping',['kModeForwardLooping',['../libaiff_8h.html#a9251177cac8bb05a06337bd422b18883',1,'libaiff.h']]],
  ['kmodenolooping',['kModeNoLooping',['../libaiff_8h.html#a5ddf30c675a2ddeada22853350e7f890',1,'libaiff.h']]],
  ['knumencs',['kNumEncs',['../aifx_8c.html#aa4432984c1a6e82153f80d2026d4996a',1,'aifx.c']]]
];
