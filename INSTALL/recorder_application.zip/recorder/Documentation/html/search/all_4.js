var searchData=
[
  ['day_5fastronomical_5ftwilight_5flength',['day_astronomical_twilight_length',['../sunriset_8c.html#a42c83daccaa81f093fee70e66d53c781',1,'day_astronomical_twilight_length(int year, int month, int day, double lon, double lat):&#160;sunriset.c'],['../sunriset_8h.html#a733b63fb6bdf87177dc1da390e08504d',1,'day_astronomical_twilight_length(int year, int month, int day, double *start, double *end):&#160;sunriset.h']]],
  ['day_5fcivil_5ftwilight_5flength',['day_civil_twilight_length',['../sunriset_8c.html#a6036767f0b570837d9849418c1d98cd9',1,'day_civil_twilight_length(int year, int month, int day, double lon, double lat):&#160;sunriset.c'],['../sunriset_8h.html#ab5dfc5d8842ec0c694d796c60c825c8e',1,'day_civil_twilight_length(int year, int month, int day, double *start, double *end):&#160;sunriset.h']]],
  ['day_5flength',['day_length',['../sunriset_8c.html#a23a59b0578ab95ef0183fc6d3c221fae',1,'day_length(int year, int month, int day, double lon, double lat):&#160;sunriset.c'],['../sunriset_8h.html#a23a59b0578ab95ef0183fc6d3c221fae',1,'day_length(int year, int month, int day, double lon, double lat):&#160;sunriset.c']]],
  ['day_5fnautical_5ftwilight_5flength',['day_nautical_twilight_length',['../sunriset_8c.html#ace42ff67ddc9b6e3b9382d8402faf4c0',1,'day_nautical_twilight_length(int year, int month, int day, double lon, double lat):&#160;sunriset.c'],['../sunriset_8h.html#a943d16bd5ea7f167dcb6a6f044923c01',1,'day_nautical_twilight_length(int year, int month, int day, double *start, double *end):&#160;sunriset.h']]],
  ['days_5fsince_5f2000_5fjan_5f0',['days_since_2000_Jan_0',['../sunriset_8c.html#a7bd37054eab4de28d200fe630368a235',1,'sunriset.c']]],
  ['decoder',['decoder',['../structdecoder.html',1,'decoder'],['../structs___a_i_f_f___ref.html#aeca14a6a7d12fbacf9a9e3736b7c2436',1,'s_AIFF_Ref::decoder()']]],
  ['default_5fgain',['DEFAULT_GAIN',['../recorder__helpers_8h.html#ae242ab0e0a91e95de561944085dbdf20',1,'recorder_helpers.h']]],
  ['default_5flatitude',['DEFAULT_LATITUDE',['../recorder__helpers_8h.html#a2eca980e5fa7a3154f835c6b076f33be',1,'recorder_helpers.h']]],
  ['default_5flongitude',['DEFAULT_LONGITUDE',['../recorder__helpers_8h.html#ab024fed6f2d786a90a99df5e378a31a5',1,'recorder_helpers.h']]],
  ['degrad',['DEGRAD',['../sunriset_8c.html#ac377a5fa64fdef02d0048cf0e27aca2c',1,'sunriset.c']]],
  ['delete',['delete',['../structdecoder.html#a3ec75917d1764c3fc406cb0d29339c73',1,'decoder']]],
  ['detune',['detune',['../structs___instrument.html#aae4ee8015cf3933a85e9e6cf5ba4bacb',1,'s_Instrument']]],
  ['do_5faifx_5fprepare',['do_aifx_prepare',['../aifx_8c.html#aaee3047d5d4ff5db0ace386dd2796686',1,'do_aifx_prepare(AIFF_Ref r):&#160;aifx.c'],['../private_8h.html#aaee3047d5d4ff5db0ace386dd2796686',1,'do_aifx_prepare(AIFF_Ref r):&#160;aifx.c']]],
  ['duration_5fdays',['DURATION_DAYS',['../recorder__helpers_8h.html#a88e886b9a390aedac31da38e9c4ceb9c',1,'recorder_helpers.h']]]
];
