var searchData=
[
  ['waitbuffering',['waitBuffering',['../recorder__helpers_8c.html#ac8508e2e129d131f3c3a67e7af6095fd',1,'waitBuffering(int num_buffers, int g_quit, struct aio_struct **aio):&#160;recorder_helpers.c'],['../recorder__helpers_8h.html#a1e9e0ad8cc5832fe2ab8f0ada4bb9aed',1,'waitBuffering(int num_buffers, int g_quit, struct aio_struct **):&#160;recorder_helpers.c']]],
  ['writebuffer',['writeBuffer',['../recorder__helpers_8c.html#ae0958bd84d3e59b0c4d0686e64c16e64',1,'writeBuffer(AIFF_Ref file, struct circ_buffer buffer_object, int channels_per_file, int num_buffers, int *ch_on, void **buf_array, dt78xx_ain_config_t *ain_cfg):&#160;recorder_helpers.c'],['../recorder__helpers_8h.html#ae0958bd84d3e59b0c4d0686e64c16e64',1,'writeBuffer(AIFF_Ref file, struct circ_buffer buffer_object, int channels_per_file, int num_buffers, int *ch_on, void **buf_array, dt78xx_ain_config_t *ain_cfg):&#160;recorder_helpers.c']]]
];
