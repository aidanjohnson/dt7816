var searchData=
[
  ['days_5fsince_5f2000_5fjan_5f0',['days_since_2000_Jan_0',['../sunriset_8c.html#a7bd37054eab4de28d200fe630368a235',1,'sunriset.c']]],
  ['default_5fgain',['DEFAULT_GAIN',['../recorder__helpers_8h.html#ae242ab0e0a91e95de561944085dbdf20',1,'recorder_helpers.h']]],
  ['default_5flatitude',['DEFAULT_LATITUDE',['../recorder__helpers_8h.html#a2eca980e5fa7a3154f835c6b076f33be',1,'recorder_helpers.h']]],
  ['default_5flongitude',['DEFAULT_LONGITUDE',['../recorder__helpers_8h.html#ab024fed6f2d786a90a99df5e378a31a5',1,'recorder_helpers.h']]],
  ['degrad',['DEGRAD',['../sunriset_8c.html#ac377a5fa64fdef02d0048cf0e27aca2c',1,'sunriset.c']]],
  ['duration_5fdays',['DURATION_DAYS',['../recorder__helpers_8h.html#a88e886b9a390aedac31da38e9c4ceb9c',1,'recorder_helpers.h']]]
];
